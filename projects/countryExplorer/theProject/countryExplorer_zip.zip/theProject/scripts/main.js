import { createCardList } from "./domBuilder.js";

createCardList();